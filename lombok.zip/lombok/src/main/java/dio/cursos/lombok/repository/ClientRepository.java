package dio.cursos.lombok.repository;

import dio.cursos.lombok.model.ClientModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClientRepository extends JpaRepository<ClientModel, Integer> {

}
