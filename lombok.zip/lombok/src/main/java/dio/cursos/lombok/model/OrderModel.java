package dio.cursos.lombok.model;

import lombok.Data;
import jakarta.persistence.*;
import java.util.List;

@Data
@Entity(name = "orderModel")
public class OrderModel {

    @Id
    private String id;

    @ManyToOne(cascade = CascadeType.ALL)
    private ClientModel client;

    @OneToMany(cascade = CascadeType.ALL)
    private List<OrderItemModel> itens;

}
