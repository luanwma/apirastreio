package dio.cursos.lombok.controller;

import dio.cursos.lombok.model.ClientModel;
import dio.cursos.lombok.repository.ClientRepository;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/api/client")
public class ClientController {

    private final ClientRepository repository;

    @GetMapping("/showAll")
    public ResponseEntity<List<ClientModel>> showAll() {
        return ResponseEntity.ok(repository.findAll());
    }

    @PostMapping("/save")
    public ResponseEntity<ClientModel>save(@RequestBody ClientModel client){
        return ResponseEntity.ok(repository.save(client));
    }

}
