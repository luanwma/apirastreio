package dio.cursos.lombok.controller;

import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import dio.cursos.lombok.model.OrderModel;
import dio.cursos.lombok.repository.OrderRepository;
import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import org.hibernate.id.GUIDGenerator;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.util.List;
import java.util.UUID;

@RestController
@AllArgsConstructor
@RequestMapping("/api/order")
public class OrderController {

    private final OrderRepository repository;

    @GetMapping("/showAll")
    public ResponseEntity<List<OrderModel>> showAll() {
        return ResponseEntity.ok(repository.findAll());
    }

    @PostMapping("/save")
    public ResponseEntity<OrderModel>save(@RequestBody OrderModel order){
        if(order.getId() == null || order.getId().isEmpty()){
            order.setId(UUID.randomUUID().toString());
        }
        return ResponseEntity.ok(repository.save(order));
    }
}
