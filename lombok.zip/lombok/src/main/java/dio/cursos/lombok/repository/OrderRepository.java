package dio.cursos.lombok.repository;

import dio.cursos.lombok.model.OrderModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderRepository extends JpaRepository<OrderModel, String> {

}
