package dio.cursos.lombok.controller;

import dio.cursos.lombok.model.ProductModel;
import dio.cursos.lombok.repository.ProductRepository;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/api/product")
public class ProductController {

    private final ProductRepository repository;

    @GetMapping("/showAll")
    public ResponseEntity<List<ProductModel>> showAll() {
        return ResponseEntity.ok(repository.findAll());
    }

    @PostMapping("/save")
    public ResponseEntity<ProductModel> save(@RequestBody ProductModel product){
        return ResponseEntity.ok(repository.save(product));
    }

}
